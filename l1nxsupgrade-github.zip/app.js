const cases=[
{id:1,name:"Neon Start",price:250,icon:"✦",color:"#8b5cff",items:[["Cyber Pistol",120,"🔫"],["Neon Knife",350,"🗡️"],["Pulse Rifle",600,"⚡"],["Void Blade",1100,"🔪"],["Quantum AK",1800,"💠"]]},
{id:2,name:"Shadow",price:500,icon:"◈",color:"#4d77ff",items:[["Night SMG",250,"🔫"],["Ghost Knife",700,"🗡️"],["Shadow Rifle",1200,"⚡"],["Black Fang",2200,"🔪"],["Phantom",4000,"💎"]]},
{id:3,name:"Cyberpunk",price:1000,icon:"◆",color:"#ff3ea5",items:[["Pink Pistol",500,"🔫"],["Synth Knife",1400,"🗡️"],["Chrome Rifle",2600,"⚡"],["Cyber Blade",5000,"🔪"],["Neon Dragon",9000,"🐉"]]},
{id:4,name:"L1nxs Elite",price:2000,icon:"♛",color:"#ffd15a",items:[["Elite SMG",900,"🔫"],["Golden Fang",2500,"🗡️"],["Royal Rifle",5000,"⚡"],["Solar Blade",9000,"🔪"],["L1nxs Crown",16000,"👑"]]}
];
let balance=5000, inventory=[], selectedBattle=1, opening=false;

const $=id=>document.getElementById(id);
function money(n){balance-=n;$("balance").textContent=balance}
function addMoney(n){balance+=n;$("balance").textContent=balance}
function showPage(id){document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));$(id).classList.add("active");document.querySelectorAll("nav button").forEach(b=>b.style.color=b.dataset.page===id?"#fff":"")}
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>showPage(b.dataset.page));

function card(c){
 return `<div class="card"><div class="caseArt" style="--c:${c.color}">${c.icon}</div><h3>${c.name}</h3><div class="muted">${c.items.length} возможных предметов</div><div class="price"><b>🪙 ${c.price}</b><button class="small" onclick="openCase(${c.id})">Открыть</button></div></div>`;
}
function renderCases(){ $("caseGrid").innerHTML=cases.map(card).join("");$("homeCases").innerHTML=cases.slice(0,3).map(card).join("")}
function renderBattle(){
 $("battleCases").innerHTML=cases.map((c,i)=>`<label class="battlePick ${i===selectedBattle?"selected":""}"><div class="caseArt" style="--c:${c.color}">${c.icon}</div><b>${c.name}</b><br><small>🪙 ${c.price}</small><br><input type="radio" name="bc" ${i===selectedBattle?"checked":""} onchange="selectedBattle=${i};renderBattle()"></label>`).join("");
}
function renderInventory(){
 if(!inventory.length){$("inventoryGrid").innerHTML='<div class="inventoryEmpty">Инвентарь пуст.<br>Открой кейс, чтобы получить первый предмет.</div>';return}
 $("inventoryGrid").innerHTML=inventory.map(x=>`<div class="card item"><div class="caseArt" style="--c:${x.color}">${x.icon}</div><h3>${x.name}</h3><div class="muted">Виртуальный предмет</div><div class="price"><b>🪙 ${x.value}</b></div></div>`).join("");
}
function weighted(items){
 let total=0;items.forEach((x,i)=>total+=i===items.length-1?8:40/(i+1));
 let r=Math.random()*total;
 for(let i=0;i<items.length;i++){let w=i===items.length-1?8:40/(i+1);r-=w;if(r<=0)return items[i]}
 return items[0];
}
function openCase(id){
 const c=cases.find(x=>x.id===id);if(balance<c.price){toast("Недостаточно виртуальных кредитов");return}
 money(c.price);opening=true;$("modal").classList.remove("hidden");$("modalTitle").textContent=c.name;$("openResult").innerHTML="";
 $("openBtn").style.display="block";$("openBtn").onclick=()=>runOpening(c);
 makeReel(c);
}
function makeReel(c){
 const arr=[];for(let i=0;i<25;i++){const it=c.items[Math.floor(Math.random()*c.items.length)];arr.push(it)}
 $("reelTrack").innerHTML=arr.map(it=>`<div class="reelItem"><span>${it[2]}</span><b>${it[0]}</b></div>`).join("");
 $("reelTrack").style.transform="translateX(0)";
}
function runOpening(c){
 if(!opening)return;opening=false;$("openBtn").style.display="none";
 const win=weighted(c.items);inventory.push({name:win[0],value:win[1],icon:win[2],color:c.color});renderInventory();
 const items=Array.from($("reelTrack").children);items[20].innerHTML=`<span>${win[2]}</span><b>${win[0]}</b>`;
 const target=20*130-($("reelTrack").parentElement.clientWidth/2-60);
 $("reelTrack").style.transition="transform 3.2s cubic-bezier(.08,.72,.08,1)";
 $("reelTrack").style.transform=`translateX(${-target}px)`;
 setTimeout(()=>{$("openResult").innerHTML=`<div class="win">Твой предмет<strong>${win[2]} ${win[0]}</strong><small>Стоимость: 🪙 ${win[1]}</small></div>`;toast("Предмет добавлен в инвентарь")},3300);
}
function closeModal(){opening=false;$("modal").classList.add("hidden")}
function toast(t){$("toast").textContent=t;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),1800)}
function demoMoney(){addMoney(1000);toast("+1000 виртуальных кредитов")}
function startBattle(){
 if(balance<500){toast("Нужно 500 виртуальных кредитов");return}
 money(500);$("startBattle").disabled=true;$("battleResult").innerHTML='<div class="battleWin">Открываем кейсы...</div>';
 setTimeout(()=>{
  const c=cases[selectedBattle],a=weighted(c.items),b=weighted(c.items);
  const playerScore=a[1],botScore=b[1];
  inventory.push({name:a[0],value:a[1],icon:a[2],color:c.color});renderInventory();
  let title=playerScore>=botScore?"Ты забрал раунд!":"Победил Rival_07";
  $("battleResult").innerHTML=`<div class="battleWin"><h2>${title}</h2><p>${a[2]} ${a[0]} — 🪙 ${a[1]}<br>VS<br>${b[2]} ${b[0]} — 🪙 ${b[1]}</p></div>`;
  $("startBattle").disabled=false;
 },1800);
}
$("startBattle").onclick=startBattle;
renderCases();renderBattle();renderInventory();$("balance").textContent=balance;
