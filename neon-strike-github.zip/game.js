(() => {
"use strict";

const canvas=document.getElementById("game");
const ctx=canvas.getContext("2d");
const hpEl=document.getElementById("hp"), ammoEl=document.getElementById("ammo"), scoreEl=document.getElementById("score");
const menu=document.getElementById("menu"), over=document.getElementById("gameover"), finalScore=document.getElementById("finalScore");
const message=document.getElementById("message");
const W=()=>innerWidth,H=()=>innerHeight;

let DPR=1, running=false, last=0, score=0, wave=1, spawnTimer=0, muzzle=0, damageFlash=0;
let player, enemies=[], bullets=[], particles=[], walls=[], pickups=[];
let keys={};

function resize(){
  DPR=Math.min(devicePixelRatio||1,2);
  canvas.width=Math.floor(W()*DPR); canvas.height=Math.floor(H()*DPR);
  ctx.setTransform(DPR,0,0,DPR,0,0);
}
addEventListener("resize",resize); resize();

function reset(){
  player={x:0,y:0,a:0,pitch:0,hp:100,ammo:12,reserve:72,reloading:false,reloadT:0,speed:3.4,cool:0,jump:0};
  enemies=[]; bullets=[]; particles=[]; pickups=[]; score=0; wave=1; spawnTimer=.2; damageFlash=0;
  makeMap(); updateHUD();
}
function makeMap(){
  walls=[
    {x:-8,y:-5,w:16,h:.45},{x:-8,y:5,w:16,h:.45},
    {x:-8,y:-5,w:.45,h:10},{x:8,y:-5,w:.45,h:10},
    {x:-4,y:-2,w:3,h:.5},{x:2,y:1,w:4,h:.5},
    {x:-1,y:-4,w:.5,h:3},{x:5,y:-3,w:.5,h:3},
    {x:-6,y:2,w:2.5,h:.5}
  ];
}
function startGame(){reset();menu.classList.add("hidden");over.classList.add("hidden");running=true;last=performance.now();requestAnimationFrame(loop)}
document.getElementById("start").onclick=startGame;
document.getElementById("restart").onclick=startGame;

function spawnEnemy(){
  const side=Math.floor(Math.random()*4), r=9, p=[[Math.random()*14-7,-r],[Math.random()*14-7,r],[-r,Math.random()*8-4],[r,Math.random()*8-4]][side];
  enemies.push({x:p[0],y:p[1],hp:100,speed:1.0+Math.random()*.35+wave*.025,shoot:1+Math.random()*2,hit:0});
}
function spawnPickup(x,y){
  if(Math.random()<.2) pickups.push({x,y,type:"ammo"});
}

function collides(x,y){
  if(x<-7.5||x>7.5||y<-4.5||y>4.5)return true;
  return walls.some(w=>x>w.x-.3&&x<w.x+w.w+.3&&y>w.y-.3&&y<w.y+w.h+.3);
}
function movePlayer(dt){
  let mx=0,my=0;
  if(keys.w)my+=1;if(keys.s)my-=1;if(keys.a)mx-=1;if(keys.d)mx+=1;
  mx+=joyX; my+=joyY;
  const len=Math.hypot(mx,my); if(len>1){mx/=len;my/=len}
  const ca=Math.cos(player.a),sa=Math.sin(player.a);
  const dx=(mx*ca-my*sa)*player.speed*dt, dy=(mx*sa+my*ca)*player.speed*dt;
  if(!collides(player.x+dx,player.y))player.x+=dx;
  if(!collides(player.x,player.y+dy))player.y+=dy;
}
function shoot(){
  if(!running||player.reloading||player.cool>0)return;
  if(player.ammo<=0){reload();return}
  player.ammo--;player.cool=.16;muzzle=.08;
  bullets.push({x:player.x+Math.cos(player.a)*.35,y:player.y+Math.sin(player.a)*.35,a:player.a,life:1.2,enemy:false});
  burst(player.x+Math.cos(player.a)*.5,player.y+Math.sin(player.a)*.5,6);
  updateHUD();
}
function reload(){
  if(player.reloading||player.ammo===12||player.reserve<=0)return;
  player.reloading=true;player.reloadT=1.0;
}
function enemyShoot(e){
  const a=Math.atan2(player.y-e.y,player.x-e.x);
  bullets.push({x:e.x,y:e.y,a:a+(Math.random()-.5)*.08,life:1.7,enemy:true});
}
function burst(x,y,n){
  for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,s=Math.random()*3;particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:.35+Math.random()*.35})}
}
function damage(n){
  player.hp=Math.max(0,player.hp-n);damageFlash=.18;updateHUD();
  if(player.hp<=0){running=false;finalScore.textContent="Счёт: "+score;over.classList.remove("hidden")}
}
function update(dt){
  if(!running)return;
  player.cool=Math.max(0,player.cool-dt);muzzle=Math.max(0,muzzle-dt);damageFlash=Math.max(0,damageFlash-dt);
  if(player.reloading){player.reloadT-=dt;if(player.reloadT<=0){const n=Math.min(12-player.ammo,player.reserve);player.ammo+=n;player.reserve-=n;player.reloading=false;updateHUD()}}
  movePlayer(dt);
  if(player.jump>0)player.jump=Math.max(0,player.jump-dt);

  spawnTimer-=dt;
  if(spawnTimer<=0){
    const count=Math.min(3+Math.floor(wave/2),8);
    if(enemies.length<count)spawnEnemy();
    spawnTimer=Math.max(.7,2.2-wave*.06);
  }

  for(const e of enemies){
    const dx=player.x-e.x,dy=player.y-e.y,d=Math.hypot(dx,dy),a=Math.atan2(dy,dx);
    if(d>1.2){
      const sp=e.speed*dt;
      const nx=e.x+Math.cos(a)*sp,ny=e.y+Math.sin(a)*sp;
      if(!collides(nx,e.y))e.x=nx;if(!collides(e.x,ny))e.y=ny;
    }else e.hit+=dt;
    e.shoot-=dt;
    if(e.shoot<=0&&d<8){enemyShoot(e);e.shoot=1.3+Math.random()*1.5}
  }

  for(let i=bullets.length-1;i>=0;i--){
    const b=bullets[i];b.x+=Math.cos(b.a)*7*dt;b.y+=Math.sin(b.a)*7*dt;b.life-=dt;
    if(b.life<=0||collides(b.x,b.y)){bullets.splice(i,1);continue}
    if(b.enemy){
      if(Math.hypot(b.x-player.x,b.y-player.y)<.45){bullets.splice(i,1);damage(9);continue}
    }else{
      let hit=false;
      for(let j=enemies.length-1;j>=0;j--){
        const e=enemies[j];
        if(Math.hypot(b.x-e.x,b.y-e.y)<.48){
          e.hp-=50;burst(e.x,e.y,8);bullets.splice(i,1);hit=true;
          if(e.hp<=0){score+=100;spawnPickup(e.x,e.y);enemies.splice(j,1);if(score%500===0)wave++}
          break;
        }
      }
      if(hit)continue;
    }
  }
  for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;if(p.life<=0)particles.splice(i,1)}
  for(let i=pickups.length-1;i>=0;i--){
    const p=pickups[i];if(Math.hypot(p.x-player.x,p.y-player.y)<.65){player.reserve+=24;pickups.splice(i,1);showMsg("+24 AMMO")}
  }
  updateHUD();
}
function updateHUD(){
  hpEl.textContent="HP "+Math.ceil(player?.hp??100);
  ammoEl.textContent="AMMO "+(player?.ammo??12)+"/"+(player?.reserve??72)+(player?.reloading?"  RELOADING":"");
  scoreEl.textContent="SCORE "+score;
}
function showMsg(t){message.textContent=t;message.style.opacity=1;setTimeout(()=>message.style.opacity=0,450)}

function project(x,y){
  const dx=x-player.x,dy=y-player.y,d=Math.hypot(dx,dy);
  let rel=Math.atan2(dy,dx)-player.a;while(rel>Math.PI)rel-=2*Math.PI;while(rel<-Math.PI)rel+=2*Math.PI;
  return {d,rel};
}
function drawWorld(){
  const w=W(),h=H();
  ctx.clearRect(0,0,w,h);
  // sky / floor
  const horizon=h*.49+(player?.pitch||0);
  const g=ctx.createLinearGradient(0,0,0,h);
  g.addColorStop(0,"#050817");g.addColorStop(.48,"#0b1230");g.addColorStop(.49,"#090d17");g.addColorStop(1,"#03050b");
  ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
  // grid
  ctx.strokeStyle="#163050";ctx.lineWidth=1;
  for(let d=1;d<14;d++){
    const y=horizon+Math.min(h*.48, (h*.48)*(1-Math.exp(-d*.35))*1.7);
    ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();
  }
  for(let x=-10;x<=10;x++){
    const px=w/2+x*w/18;ctx.beginPath();ctx.moveTo(w/2,horizon);ctx.lineTo(px,h);ctx.stroke();
  }
  // walls as simple pseudo-3D rectangles
  const objects=[];
  walls.forEach(wall=>{
    const pts=[[wall.x,wall.y],[wall.x+wall.w,wall.y],[wall.x+wall.w,wall.y+wall.h],[wall.x,wall.y+wall.h]];
    objects.push({type:"wall",pts,d:Math.min(...pts.map(p=>project(p[0],p[1]).d))});
  });
  enemies.forEach(e=>objects.push({type:"enemy",e,d:project(e.x,e.y).d}));
  pickups.forEach(p=>objects.push({type:"pickup",p,d:project(p.x,p.y).d}));
  objects.sort((a,b)=>b.d-a.d);
  for(const o of objects)renderObject(o,w,h,horizon);
  for(const b of bullets){const q=project(b.x,b.y);if(Math.abs(q.rel)<1.2&&q.d<14){const sx=w/2+Math.tan(q.rel)*w*.55,sy=horizon+20/q.d;ctx.fillStyle=b.enemy?"#ff5b8d":"#fff56b";ctx.beginPath();ctx.arc(sx,sy,3,0,7);ctx.fill()}}
  if(muzzle>0){ctx.fillStyle="#fff7a8";ctx.beginPath();ctx.arc(w/2,h*.51,18+Math.random()*15,0,7);ctx.fill()}
  if(damageFlash>0){ctx.fillStyle=`rgba(255,20,80,${damageFlash*2})`;ctx.fillRect(0,0,w,h)}
}
function renderObject(o,w,h,horizon){
  if(o.type==="wall"){
    const ps=o.pts.map(p=>{const q=project(p[0],p[1]);return {q,x:w/2+Math.tan(q.rel)*w*.55,d:q.d}});
    const visible=ps.filter(v=>Math.abs(v.q.rel)<1.4);
    if(visible.length<2)return;
    const near=Math.max(.2,Math.min(...ps.map(v=>v.d)));
    const x1=Math.max(-100,Math.min(w+100,...ps.map(v=>v.x))),x2=Math.min(w+100,Math.max(-100,...ps.map(v=>v.x)));
    const hh=Math.min(h*.8,240/near), y=horizon-hh;
    ctx.fillStyle="#152548";ctx.strokeStyle="#32d8ff88";ctx.lineWidth=2;ctx.fillRect(x1,y,Math.max(3,x2-x1),hh);ctx.strokeRect(x1,y,Math.max(3,x2-x1),hh);
    return;
  }
  const q=project(o.type==="enemy"?o.e.x:o.p.x,o.type==="enemy"?o.e.y:o.p.y);
  if(Math.abs(q.rel)>1.25||q.d<.2)return;
  const sx=w/2+Math.tan(q.rel)*w*.55;
  const size=Math.min(h*.7,360/q.d);
  if(o.type==="enemy"){
    const sy=horizon-size*.55;
    ctx.fillStyle="#ff2d6f";ctx.shadowBlur=18;ctx.shadowColor="#ff2d6f";
    ctx.fillRect(sx-size*.22,sy,size*.44,size*.8);
    ctx.fillStyle="#ffcfdb";ctx.fillRect(sx-size*.15,sy-size*.22,size*.3,size*.18);
    ctx.shadowBlur=0;
    ctx.fillStyle="#141a2b";ctx.fillRect(sx-size*.3,sy-size*.35,size*.6,5);
    ctx.fillStyle="#55ff82";ctx.fillRect(sx-size*.3,sy-size*.35,size*.6*(o.e.hp/100),5);
  }else{
    ctx.fillStyle="#ffe95a";ctx.shadowBlur=15;ctx.shadowColor="#ffe95a";ctx.beginPath();ctx.arc(sx,horizon-size*.25,size*.12,0,7);ctx.fill();ctx.shadowBlur=0;
  }
}
function loop(t){
  const dt=Math.min(.033,(t-last)/1000);last=t;update(dt);drawWorld();
  if(running)requestAnimationFrame(loop);
}

// Keyboard / desktop
addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true;if(e.code==="Space")shoot();if(e.key.toLowerCase()==="r")reload()});
addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);

// Touch joystick
let joyX=0,joyY=0,joyActive=false;
const joy=document.getElementById("joystick"),stick=document.getElementById("stick");
function joyMove(e){
  const r=joy.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
  let dx=e.clientX-cx,dy=e.clientY-cy,max=r.width*.35,l=Math.hypot(dx,dy);
  if(l>max){dx=dx/l*max;dy=dy/l*max}
  joyX=dx/max;joyY=-dy/max;stick.style.transform=`translate(${dx}px,${dy}px)`;
}
joy.addEventListener("pointerdown",e=>{joyActive=true;joy.setPointerCapture(e.pointerId);joyMove(e)});
joy.addEventListener("pointermove",e=>{if(joyActive)joyMove(e)});
joy.addEventListener("pointerup",()=>{joyActive=false;joyX=joyY=0;stick.style.transform=""});
document.getElementById("fire").addEventListener("pointerdown",e=>{e.preventDefault();shoot()});
document.getElementById("reload").addEventListener("pointerdown",e=>{e.preventDefault();reload()});
document.getElementById("jump").addEventListener("pointerdown",e=>{e.preventDefault();player.jump=.25});

// Swipe look
let look=null;
canvas.addEventListener("pointerdown",e=>{if(e.clientX>W()*.38){look={x:e.clientX,y:e.clientY,id:e.pointerId};canvas.setPointerCapture(e.pointerId)}});
canvas.addEventListener("pointermove",e=>{
  if(!look||e.pointerId!==look.id)return;
  const dx=e.clientX-look.x,dy=e.clientY-look.y;
  player.a+=dx*.008;player.pitch=Math.max(-35,Math.min(35,player.pitch-dy*.15));
  look.x=e.clientX;look.y=e.clientY;
});
canvas.addEventListener("pointerup",e=>{if(look&&e.pointerId===look.id)look=null});
canvas.addEventListener("pointercancel",()=>look=null);

reset();
drawWorld();
})();