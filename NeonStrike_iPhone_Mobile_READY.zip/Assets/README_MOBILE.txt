NEON STRIKE - iPHONE MOBILE CONTROLS

The project now creates a touch HUD automatically at runtime.

Landscape controls:
- Left side: virtual joystick = movement
- Right side: drag = camera look
- FIRE = shoot
- AIM = hold to aim / lower FOV
- R = reload
- 1 / 2 / 3 = weapon switch
- ↑ = jump
- C = crouch
- RUN = sprint
- USE = hold to plant/defuse the bomb when close to the objective

For editor testing:
- Set MobileInputController.forceMobileControls = true in the inspector, or
- Use the normal keyboard/mouse controls when running on PC.

Recommended iPhone orientation: Landscape Left/Right.
Recommended target: 60 FPS on normal devices; 120 FPS on capable devices.
