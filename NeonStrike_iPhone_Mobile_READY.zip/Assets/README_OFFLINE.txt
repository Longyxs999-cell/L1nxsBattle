
NEON STRIKE - OFFLINE UNITY 6 PROTOTYPE

This is an original tactical FPS prototype. It does not use Standoff 2 assets, names, maps, sounds, or code.

Quick setup:
1. Create a Unity 6.3 LTS 3D URP project.
2. Install Input System from Package Manager.
3. Create Assets/Scripts and copy all .cs files here.
4. In an empty scene create an empty GameObject named "Prototype".
5. Add PrototypeBootstrap.cs to it.
6. Press Play.

Controls:
WASD - move
Shift - sprint
Ctrl - crouch
Space - jump
Mouse - look
Left mouse - fire
R - reload
1/2/3 - weapon
Esc - release mouse
E - hold to plant/defuse near a bomb site

The current prototype uses a simple waypoint bot system rather than NavMesh. AI Navigation can be added later.

The online version should use Netcode for GameObjects 2.x + Unity Transport 2.x after the offline mechanics are stable.
