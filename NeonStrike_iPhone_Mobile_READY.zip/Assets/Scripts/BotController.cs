
using System.Collections.Generic;
using UnityEngine;

public class BotController : MonoBehaviour
{
    public float moveSpeed = 2.6f;
    public float turnSpeed = 6f;
    public float attackRange = 45f;
    public float reactionTime = 0.45f;

    private Health health;
    private Health target;
    private List<Transform> waypoints;
    private int waypointIndex;
    private float nextAttackTime;
    private float targetScanTime;

    public void Initialize(Team team, List<Transform> points)
    {
        health = GetComponent<Health>();
        health.team = team;
        health.isBot = true;
        waypoints = points;
        waypointIndex = Random.Range(0, waypoints.Count);
    }

    private void Update()
    {
        if (health == null || !health.IsAlive) return;

        targetScanTime -= Time.deltaTime;
        if (targetScanTime <= 0f)
        {
            targetScanTime = reactionTime;
            target = FindNearestEnemy();
        }

        if (TryObjective()) return;

        if (target != null && target.IsAlive)
        {
            float distance = Vector3.Distance(transform.position, target.transform.position);
            if (distance <= attackRange && HasLineOfSight(target))
            {
                Face(target.transform.position);
                if (Time.time >= nextAttackTime)
                {
                    nextAttackTime = Time.time + 0.35f;
                    FireAtTarget(target);
                }
            }
            else
            {
                MoveTo(target.transform.position);
            }
        }
        else if (waypoints != null && waypoints.Count > 0)
        {
            Transform point = waypoints[waypointIndex];
            MoveTo(point.position);
            if (Vector3.Distance(transform.position, point.position) < 1.4f)
                waypointIndex = (waypointIndex + 1) % waypoints.Count;
        }
    }

    private bool TryObjective()
    {
        TacticalGameManager gm = TacticalGameManager.Instance;
        if (gm == null || gm.bomb == null || !gm.roundActive) return false;

        if (health.team == gm.attackers && gm.bomb.IsCarried && gm.bomb.Carrier == health)
        {
            BombSite site = FindNearestSite();
            if (site == null) return false;
            float d = Vector3.Distance(transform.position, site.transform.position);
            if (d > site.radius * 0.8f) { MoveTo(site.transform.position); return true; }
            gm.bomb.TryPlant(health, site);
            return true;
        }

        if (health.team != gm.attackers && gm.bomb.IsPlanted && gm.bomb.PlantedSite != null)
        {
            float d = Vector3.Distance(transform.position, gm.bomb.PlantedSite.transform.position);
            if (d > gm.bomb.PlantedSite.radius * 0.8f) { MoveTo(gm.bomb.PlantedSite.transform.position); return true; }
            gm.bomb.TryDefuse(health);
            return true;
        }
        return false;
    }

    private BombSite FindNearestSite()
    {
        BombSite[] sites = FindObjectsByType<BombSite>(FindObjectsSortMode.None);
        BombSite best = null; float bestDist = float.MaxValue;
        foreach (BombSite s in sites) { float d = Vector3.Distance(transform.position, s.transform.position); if (d < bestDist) { bestDist = d; best = s; } }
        return best;
    }

    private Health FindNearestEnemy()
    {
        Health[] all = FindObjectsByType<Health>(FindObjectsSortMode.None);
        Health best = null;
        float bestDist = float.MaxValue;

        foreach (Health h in all)
        {
            if (!h.IsAlive || h.team == health.team) continue;
            float d = Vector3.Distance(transform.position, h.transform.position);
            if (d < bestDist)
            {
                bestDist = d;
                best = h;
            }
        }

        return best;
    }

    private bool HasLineOfSight(Health enemy)
    {
        Vector3 origin = transform.position + Vector3.up * 1.4f;
        Vector3 targetPoint = enemy.transform.position + Vector3.up * 1.2f;
        Vector3 dir = targetPoint - origin;

        if (Physics.Raycast(origin, dir.normalized, out RaycastHit hit, dir.magnitude))
            return hit.collider.GetComponentInParent<Health>() == enemy;

        return false;
    }

    private void MoveTo(Vector3 destination)
    {
        Vector3 flat = destination - transform.position;
        flat.y = 0f;

        if (flat.sqrMagnitude < 0.05f) return;

        Vector3 dir = flat.normalized;
        Face(transform.position + dir * 2f);
        transform.position += dir * moveSpeed * Time.deltaTime;
    }

    private void Face(Vector3 point)
    {
        Vector3 flat = point - transform.position;
        flat.y = 0f;
        if (flat.sqrMagnitude < 0.01f) return;
        Quaternion targetRot = Quaternion.LookRotation(flat);
        transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, turnSpeed * Time.deltaTime);
    }

    private void FireAtTarget(Health enemy)
    {
        Vector3 origin = transform.position + Vector3.up * 1.45f;
        Vector3 targetPoint = enemy.transform.position + Vector3.up * Random.Range(1.0f, 1.65f);
        Vector3 dir = (targetPoint - origin).normalized;

        if (Physics.Raycast(origin, dir, out RaycastHit hit, attackRange))
        {
            Health h = hit.collider.GetComponentInParent<Health>();
            if (h == enemy)
            {
                bool head = hit.collider.CompareTag("Head");
                h.TakeDamage(head ? 55 : 25, gameObject, head);
            }
        }
    }
}
