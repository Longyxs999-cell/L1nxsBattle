
using UnityEngine;

public class BombController : MonoBehaviour
{
    public bool IsCarried { get; private set; }
    public bool IsPlanted { get; private set; }
    public BombSite PlantedSite { get; private set; }
    public Health Carrier => carrier;

    public float plantDuration = 2.5f;
    public float defuseDuration = 4.0f;
    public float detonationTime = 25f;

    private float timer;
    private float actionTimer;
    private bool actionActive;
    private Health carrier;

    public void GiveTo(Health player)
    {
        carrier = player;
        IsCarried = player != null;
        IsPlanted = false;
        PlantedSite = null;
        actionActive = false;
        timer = 0f;
    }

    public bool TryPlant(Health player, BombSite site)
    {
        if (!IsCarried || carrier != player || IsPlanted || site == null) return false;
        actionActive = true;
        actionTimer += Time.deltaTime;
        if (actionTimer >= plantDuration)
        {
            IsPlanted = true;
            IsCarried = false;
            carrier = null;
            PlantedSite = site;
            timer = detonationTime;
            actionActive = false;
            actionTimer = 0f;
            TacticalGameManager.Instance?.OnBombPlanted(site);
            return true;
        }
        return false;
    }

    public bool TryDefuse(Health player)
    {
        if (!IsPlanted || PlantedSite == null || player == null) return false;
        if (TacticalGameManager.Instance != null && player.team == TacticalGameManager.Instance.attackers) return false;

        actionActive = true;
        actionTimer += Time.deltaTime;
        if (actionTimer >= defuseDuration)
        {
            IsPlanted = false;
            timer = 0f;
            actionActive = false;
            actionTimer = 0f;
            TacticalGameManager.Instance?.OnBombDefused();
            return true;
        }
        return false;
    }

    public void CancelAction()
    {
        actionActive = false;
        actionTimer = 0f;
    }

    private void Update()
    {
        if (!IsPlanted) return;

        timer -= Time.deltaTime;
        if (timer <= 0f)
        {
            timer = 0f;
            IsPlanted = false;
            TacticalGameManager.Instance?.OnBombExploded();
        }
    }

    public float ActionProgress => actionActive
        ? Mathf.Clamp01(actionTimer / (IsPlanted ? defuseDuration : plantDuration))
        : 0f;

    public float TimeRemaining => IsPlanted ? Mathf.Max(0f, timer) : 0f;
}
