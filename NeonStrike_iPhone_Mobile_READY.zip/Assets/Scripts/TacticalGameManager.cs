
using System.Collections.Generic;
using UnityEngine;

public class TacticalGameManager : MonoBehaviour
{
    public static TacticalGameManager Instance { get; private set; }

    public float roundDuration = 150f;
    public int roundsToWin = 5;

    public Team attackers = Team.Orange;
    public int blueScore;
    public int orangeScore;

    public BombController bomb;
    public BombSite siteA;
    public BombSite siteB;

    private float roundTimer;
    private int roundNumber;
    private bool roundActive;
    private string status = "Подготовка";

    public float RoundTime => roundTimer;
    public int RoundNumber => roundNumber;
    public bool RoundActive => roundActive;
    public string Status => status;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    private void Start()
    {
        StartRound();
    }

    private void Update()
    {
        if (!roundActive) return;

        roundTimer -= Time.deltaTime;
        if (roundTimer <= 0f)
        {
            roundTimer = 0f;
            EndRound(Team.Blue, "Время вышло: защита победила");
        }

        if (bomb != null && bomb.IsPlanted)
            status = $"Бомба установлена: {bomb.TimeRemaining:0.0}s";
    }

    public void StartRound()
    {
        roundNumber++;
        roundTimer = roundDuration;
        roundActive = true;
        status = $"Раунд {roundNumber}: готовьтесь";

        if (bomb != null)
        {
            bomb.CancelAction();
            bomb.GiveTo(FindBombCarrier());
        }

        ResetPlayers();
    }

    private Health FindBombCarrier()
    {
        Health fallback = null;
        Health[] players = FindObjectsByType<Health>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (Health h in players)
        {
            if (h.team != attackers || !h.gameObject.activeSelf) continue;
            if (!h.isBot) return h;
            fallback = h;
        }
        return fallback;
    }

    private void ResetPlayers()
    {
        SpawnPoint[] spawns = FindObjectsByType<SpawnPoint>(FindObjectsSortMode.None);
        List<Health> all = new List<Health>(
            FindObjectsByType<Health>(FindObjectsInactive.Include, FindObjectsSortMode.None));

        foreach (Health h in all)
        {
            if (h == null) continue;
            h.ResetHealth();

            SpawnPoint baseSpawn = null;
            foreach (SpawnPoint sp in spawns)
            {
                if (sp.team == h.team)
                {
                    baseSpawn = sp;
                    break;
                }
            }

            if (baseSpawn != null)
            {
                Vector3 offset = h.isBot
                    ? new Vector3(Random.Range(-4f, 4f), 0f, Random.Range(-3f, 3f))
                    : Vector3.zero;
                h.transform.SetPositionAndRotation(
                    baseSpawn.transform.position + offset,
                    baseSpawn.transform.rotation);
            }
        }
    }

    public void RegisterKill(GameObject attacker, GameObject victim, bool headshot)
    {
        if (!roundActive) return;

        Health a = attacker != null ? attacker.GetComponent<Health>() : null;
        Health v = victim != null ? victim.GetComponent<Health>() : null;
        if (a == null || v == null) return;

        int blueAlive = 0;
        int orangeAlive = 0;
        foreach (Health h in FindObjectsByType<Health>(FindObjectsSortMode.None))
        {
            if (!h.IsAlive) continue;
            if (h.team == Team.Blue) blueAlive++;
            else orangeAlive++;
        }

        if (blueAlive == 0)
            EndRound(Team.Orange, "Команда Orange уничтожила защитников");
        else if (orangeAlive == 0)
            EndRound(Team.Blue, "Команда Blue уничтожила атакующих");
    }

    public void OnBombPlanted(BombSite site)
    {
        if (!roundActive) return;
        status = $"Бомба установлена на {site.siteId}";
    }

    public void OnBombDefused()
    {
        if (!roundActive) return;
        EndRound(Team.Blue, "Бомба обезврежена");
    }

    public void OnBombExploded()
    {
        if (!roundActive) return;
        EndRound(Team.Orange, "Бомба взорвалась");
    }

    private void EndRound(Team winner, string message)
    {
        if (!roundActive) return;

        roundActive = false;
        status = message;

        if (winner == Team.Blue) blueScore++;
        else orangeScore++;

        Invoke(nameof(StartNextRound), 4f);
    }

    private void StartNextRound()
    {
        if (blueScore >= roundsToWin || orangeScore >= roundsToWin)
        {
            status = blueScore > orangeScore ? "ПОБЕДА BLUE" : "ПОБЕДА ORANGE";
            Invoke(nameof(RestartMatch), 5f);
            return;
        }

        attackers = attackers == Team.Orange ? Team.Blue : Team.Orange;
        StartRound();
    }

    private void RestartMatch()
    {
        blueScore = 0;
        orangeScore = 0;
        roundNumber = 0;
        attackers = Team.Orange;
        StartRound();
    }
}

public class SpawnPoint : MonoBehaviour
{
    public Team team;
    public Health target;
}
