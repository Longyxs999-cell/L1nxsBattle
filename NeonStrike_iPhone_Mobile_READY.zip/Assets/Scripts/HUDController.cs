
using UnityEngine;
using UnityEngine.UI;

public class HUDController : MonoBehaviour
{
    public Text scoreText;
    public Text timerText;
    public Text statusText;
    public Text ammoText;
    public Text weaponText;
    public Text healthText;

    private PlayerController player;
    private WeaponController weapon;
    private Health health;

    public void Bind(PlayerController p)
    {
        player = p;
        weapon = p.weapon;
        health = p.GetComponent<Health>();
    }

    private void Update()
    {
        if (TacticalGameManager.Instance == null) return;

        TacticalGameManager gm = TacticalGameManager.Instance;
        scoreText.text = $"BLUE {gm.blueScore}  :  {gm.orangeScore} ORANGE";
        timerText.text = gm.RoundTime.ToString("0");
        statusText.text = gm.Status;

        if (weapon != null)
        {
            ammoText.text = $"{weapon.AmmoInMagazine} / {weapon.ReserveAmmo}";
            weaponText.text = weapon.Current.displayName;
        }

        if (health != null)
            healthText.text = $"HP {health.CurrentHealth}";
    }
}
