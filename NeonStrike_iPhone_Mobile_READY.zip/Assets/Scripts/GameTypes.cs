
using UnityEngine;

public enum Team
{
    Blue,
    Orange
}

public enum WeaponKind
{
    Pistol,
    Rifle,
    Sniper
}

[System.Serializable]
public class WeaponConfig
{
    public WeaponKind kind;
    public string displayName;
    public int damage;
    public float range;
    public float fireRate;
    public int magazineSize;
    public int reserveAmmo;
    public float reloadTime;
    public float recoil;
    public bool automatic;

    public WeaponConfig(WeaponKind kind, string name, int damage, float range, float fireRate,
        int magazine, int reserve, float reload, float recoil, bool automatic)
    {
        this.kind = kind;
        displayName = name;
        this.damage = damage;
        this.range = range;
        this.fireRate = fireRate;
        magazineSize = magazine;
        reserveAmmo = reserve;
        reloadTime = reload;
        this.recoil = recoil;
        this.automatic = automatic;
    }

    public static WeaponConfig Pistol()
    {
        return new WeaponConfig(WeaponKind.Pistol, "Vektor-9", 34, 80f, 4.0f, 12, 60, 1.25f, 1.0f, false);
    }

    public static WeaponConfig Rifle()
    {
        return new WeaponConfig(WeaponKind.Rifle, "AR-27", 28, 110f, 10.0f, 30, 120, 2.0f, 1.7f, true);
    }

    public static WeaponConfig Sniper()
    {
        return new WeaponConfig(WeaponKind.Sniper, "SR-11", 95, 180f, 1.2f, 5, 25, 2.4f, 3.5f, false);
    }
}
