
using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    public Camera playerCamera;
    public Transform weaponPivot;
    public WeaponController weapon;
    public float walkSpeed = 4.2f;
    public float sprintSpeed = 6.5f;
    public float crouchSpeed = 2.2f;
    public float jumpHeight = 1.15f;
    public float gravity = -22f;
    public float mouseSensitivity = 0.12f;

    private CharacterController controller;
    private float verticalVelocity;
    private float pitch;
    private bool crouching;
    public float interactDistance = 3.5f;
    public bool mobileControlsEnabled = true;

    public bool IsCrouching => crouching;

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
    }

    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private void Update()
    {
        Health health = GetComponent<Health>();
        if (health != null && !health.IsAlive) return;

        MobileInputController mobile = MobileInputController.Instance;
        bool useMobile = mobileControlsEnabled && mobile != null && mobile.IsMobile;

        Look(useMobile ? mobile.Look : Vector2.zero);
        Move(useMobile ? mobile.Move : Vector2.zero, useMobile ? mobile.SprintHeld : false);

        if (useMobile)
        {
            if (mobile.CrouchPressed) crouching = !crouching;
            if (mobile.JumpPressed && controller.isGrounded)
                verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);
            HandleBombInteraction(mobile.BombHeld);
        }
        else
        {
            HandleKeyboardInput();
            HandleBombInteraction(Keyboard.current != null && Keyboard.current.eKey.isPressed);
        }
    }

    private void HandleKeyboardInput()
    {
        if (Keyboard.current == null) return;
        if (Keyboard.current.leftCtrlKey.wasPressedThisFrame) crouching = !crouching;
        if (Keyboard.current.spaceKey.wasPressedThisFrame && controller.isGrounded)
            verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);
        if (Keyboard.current.escapeKey.wasPressedThisFrame)
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }

    private void Look(Vector2 mobileDelta)
    {
        if (playerCamera == null) return;
        Vector2 delta = mobileDelta;
        if (delta == Vector2.zero && Mouse.current != null && !IsMobileActive())
            delta = Mouse.current.delta.ReadValue();

        float sensitivity = IsMobileActive() ? mouseSensitivity * 0.85f : mouseSensitivity;
        float yaw = delta.x * sensitivity;
        float lookY = delta.y * sensitivity;
        transform.Rotate(Vector3.up * yaw);
        pitch -= lookY;
        pitch = Mathf.Clamp(pitch, -88f, 88f);
        playerCamera.transform.localRotation = Quaternion.Euler(pitch, 0f, 0f);
    }

    private bool IsMobileActive()
    {
        return mobileControlsEnabled && MobileInputController.Instance != null && MobileInputController.Instance.IsMobile;
    }

    private void Move(Vector2 input, bool mobileSprint)
    {
        if (!IsMobileActive() && Keyboard.current != null)
        {
            input = Vector2.zero;
            if (Keyboard.current.wKey.isPressed) input.y += 1;
            if (Keyboard.current.sKey.isPressed) input.y -= 1;
            if (Keyboard.current.aKey.isPressed) input.x -= 1;
            if (Keyboard.current.dKey.isPressed) input.x += 1;
            input = Vector2.ClampMagnitude(input, 1f);
        }

        bool sprint = IsMobileActive() ? mobileSprint && !crouching : Keyboard.current != null && Keyboard.current.leftShiftKey.isPressed && !crouching;
        float speed = crouching ? crouchSpeed : sprint ? sprintSpeed : walkSpeed;
        Vector3 move = transform.right * input.x + transform.forward * input.y;
        controller.Move(move * speed * Time.deltaTime);

        if (controller.isGrounded && verticalVelocity < 0) verticalVelocity = -2f;
        verticalVelocity += gravity * Time.deltaTime;
        controller.Move(Vector3.up * verticalVelocity * Time.deltaTime);

        Vector3 camLocal = playerCamera.transform.localPosition;
        float targetY = crouching ? 1.05f : 1.65f;
        camLocal.y = Mathf.Lerp(camLocal.y, targetY, 12f * Time.deltaTime);
        playerCamera.transform.localPosition = camLocal;
    }

    private void Look()
    {
        if (Mouse.current == null || playerCamera == null) return;

        Vector2 delta = Mouse.current.delta.ReadValue();
        float yaw = delta.x * mouseSensitivity;
        float lookY = delta.y * mouseSensitivity;

        transform.Rotate(Vector3.up * yaw);

        pitch -= lookY;
        pitch = Mathf.Clamp(pitch, -88f, 88f);
        playerCamera.transform.localRotation = Quaternion.Euler(pitch, 0f, 0f);
    }

    private void Move()
    {
        if (Keyboard.current == null) return;

        Vector2 input = Vector2.zero;
        if (Keyboard.current.wKey.isPressed) input.y += 1;
        if (Keyboard.current.sKey.isPressed) input.y -= 1;
        if (Keyboard.current.aKey.isPressed) input.x -= 1;
        if (Keyboard.current.dKey.isPressed) input.x += 1;
        input = Vector2.ClampMagnitude(input, 1f);

        bool sprint = Keyboard.current.leftShiftKey.isPressed && !crouching;
        float speed = crouching ? crouchSpeed : sprint ? sprintSpeed : walkSpeed;

        Vector3 move = transform.right * input.x + transform.forward * input.y;
        controller.Move(move * speed * Time.deltaTime);

        if (controller.isGrounded && verticalVelocity < 0)
            verticalVelocity = -2f;

        verticalVelocity += gravity * Time.deltaTime;
        controller.Move(Vector3.up * verticalVelocity * Time.deltaTime);

        Vector3 camLocal = playerCamera.transform.localPosition;
        float targetY = crouching ? 1.05f : 1.65f;
        camLocal.y = Mathf.Lerp(camLocal.y, targetY, 12f * Time.deltaTime);
        playerCamera.transform.localPosition = camLocal;
    }


    private void HandleBombInteraction(bool pressed)
    {
        if (!pressed) return;
        if (TacticalGameManager.Instance == null || TacticalGameManager.Instance.bomb == null) return;

        BombController bomb = TacticalGameManager.Instance.bomb;
        Health me = GetComponent<Health>();
        if (me == null || !me.IsAlive) return;

        if (!bomb.IsPlanted)
        {
            if (me.team != TacticalGameManager.Instance.attackers) return;

            BombSite nearest = null;
            float best = float.MaxValue;
            BombSite[] sites = FindObjectsByType<BombSite>(FindObjectsSortMode.None);
            foreach (BombSite site in sites)
            {
                float d = Vector3.Distance(transform.position, site.transform.position);
                if (d < site.radius && d < best)
                {
                    best = d;
                    nearest = site;
                }
            }

            if (nearest != null)
                bomb.TryPlant(me, nearest);
        }
        else
        {
            if (bomb.PlantedSite == null) return;
            if (Vector3.Distance(transform.position, bomb.PlantedSite.transform.position) <= bomb.PlantedSite.radius)
                bomb.TryDefuse(me);
        }
    }

    public void ApplyRecoil(float amount)
    {
        pitch = Mathf.Clamp(pitch - amount, -88f, 88f);
    }
}
