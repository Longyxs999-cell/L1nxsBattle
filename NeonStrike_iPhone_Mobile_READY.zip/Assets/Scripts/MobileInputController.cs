using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem.EnhancedTouch;
using Unity.Collections;
using Touch = UnityEngine.InputSystem.EnhancedTouch.Touch;

/// <summary>
/// Touch controls for iPhone/iPad. It creates the whole mobile HUD at runtime,
/// so no manual Canvas setup is required.
/// </summary>
public class MobileInputController : MonoBehaviour
{
    public static MobileInputController Instance { get; private set; }

    public Vector2 Move { get; private set; }
    public Vector2 Look { get; private set; }
    public bool FireHeld { get; private set; }
    public bool AimHeld { get; private set; }
    public bool SprintHeld { get; private set; }
    public bool BombHeld { get; private set; }
    public bool JumpPressed { get; private set; }
    public bool CrouchPressed { get; private set; }
    public bool ReloadPressed { get; private set; }
    public int WeaponPressed { get; private set; } = -1;

    public bool IsMobile => Application.isMobilePlatform || forceMobileControls;
    public bool forceMobileControls = false;

    private Canvas canvas;
    private RectTransform moveZone;
    private RectTransform lookZone;
    private RectTransform joystickBase;
    private RectTransform joystickKnob;
    private readonly List<ControlButton> buttons = new List<ControlButton>();
    private int moveFinger = -1;
    private int lookFinger = -1;
    private Vector2 moveStart;
    private Vector2 lastLook;

    private class ControlButton
    {
        public RectTransform rect;
        public string action;
        public bool held;
        public int fingerId = -1;
    }

    private void Awake()
    {
        EnhancedTouchSupport.Enable();
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
        CreateUI();
    }

    private void Update()
    {
        Move = Vector2.zero;
        Look = Vector2.zero;
        FireHeld = false;
        AimHeld = false;
        SprintHeld = false;
        BombHeld = false;
        JumpPressed = false;
        CrouchPressed = false;
        ReloadPressed = false;
        WeaponPressed = -1;

        if (!IsMobile)
            return;

        for (int i = 0; i < buttons.Count; i++)
            buttons[i].held = false;

        ReadOnlyArray<Touch> touches = Touch.activeTouches;
        HashSet<int> activeIds = new HashSet<int>();

        foreach (Touch touch in touches)
        {
            activeIds.Add(touch.finger.index);
            int fingerId = touch.finger.index;
            Vector2 pos = touch.screenPosition;

            if (moveFinger < 0 && touch.phase == UnityEngine.InputSystem.TouchPhase.Began && Contains(moveZone, pos))
            {
                moveFinger = fingerId;
                moveStart = pos;
                SetJoystick(pos, pos);
            }
            else if (fingerId == moveFinger)
            {
                Vector2 delta = pos - moveStart;
                float radius = Mathf.Min(Screen.width, Screen.height) * 0.13f;
                Move = Vector2.ClampMagnitude(delta / Mathf.Max(radius, 1f), 1f);
                SetJoystick(moveStart, moveStart + Move * radius);
                if (touch.phase == UnityEngine.InputSystem.TouchPhase.Ended || touch.phase == UnityEngine.InputSystem.TouchPhase.Canceled)
                    moveFinger = -1;
            }

            if (lookFinger < 0 && touch.phase == UnityEngine.InputSystem.TouchPhase.Began && Contains(lookZone, pos))
            {
                lookFinger = fingerId;
                lastLook = pos;
            }
            else if (fingerId == lookFinger)
            {
                if (touch.phase == UnityEngine.InputSystem.TouchPhase.Moved)
                {
                    Look = touch.screenPosition - lastLook;
                    lastLook = touch.screenPosition;
                }
                if (touch.phase == UnityEngine.InputSystem.TouchPhase.Ended || touch.phase == UnityEngine.InputSystem.TouchPhase.Canceled)
                    lookFinger = -1;
            }

            for (int b = 0; b < buttons.Count; b++)
            {
                ControlButton button = buttons[b];
                if (!Contains(button.rect, pos))
                    continue;

                if (touch.phase == UnityEngine.InputSystem.TouchPhase.Began && button.fingerId < 0)
                    button.fingerId = fingerId;

                if (button.fingerId == fingerId)
                {
                    button.held = true;
                    if (touch.phase == UnityEngine.InputSystem.TouchPhase.Began)
                        Trigger(button.action);
                    if (touch.phase == UnityEngine.InputSystem.TouchPhase.Ended || touch.phase == UnityEngine.InputSystem.TouchPhase.Canceled)
                        button.fingerId = -1;
                }
            }
        }

        for (int i = 0; i < buttons.Count; i++)
        {
            if (buttons[i].fingerId >= 0 && !activeIds.Contains(buttons[i].fingerId))
                buttons[i].fingerId = -1;
        }

        if (moveFinger < 0)
        {
            Move = Vector2.zero;
            SetJoystick(Vector2.zero, Vector2.zero);
        }

        for (int i = 0; i < buttons.Count; i++)
        {
            ControlButton b = buttons[i];
            if (!b.held) continue;
            if (b.action == "Fire") FireHeld = true;
            if (b.action == "Aim") AimHeld = true;
            if (b.action == "Sprint") SprintHeld = true;
            if (b.action == "Bomb") BombHeld = true;
        }
    }

    private void Trigger(string action)
    {
        if (action == "Jump") JumpPressed = true;
        else if (action == "Crouch") CrouchPressed = true;
        else if (action == "Reload") ReloadPressed = true;
        else if (action.StartsWith("Weapon"))
            int.TryParse(action.Substring(6), out WeaponPressed);
    }

    private bool Contains(RectTransform rect, Vector2 screenPoint)
    {
        return rect != null && RectTransformUtility.RectangleContainsScreenPoint(rect, screenPoint, null);
    }

    private void SetJoystick(Vector2 basePos, Vector2 knobPos)
    {
        if (joystickBase == null || joystickKnob == null) return;
        if (basePos == Vector2.zero)
        {
            joystickBase.gameObject.SetActive(false);
            return;
        }
        joystickBase.gameObject.SetActive(true);
        joystickBase.position = basePos;
        joystickKnob.position = knobPos;
    }

    private void OnDestroy()
    {
        if (Instance == this) Instance = null;
        EnhancedTouchSupport.Disable();
    }

    private void CreateUI()
    {
        GameObject canvasObj = new GameObject("MobileControls");
        canvasObj.transform.SetParent(transform, false);
        canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObj.AddComponent<CanvasScaler>().uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        canvas.GetComponent<CanvasScaler>().referenceResolution = new Vector2(1920, 1080);
        canvas.GetComponent<CanvasScaler>().matchWidthOrHeight = 0.5f;
        canvasObj.AddComponent<GraphicRaycaster>();

        moveZone = CreateZone(canvas.transform, "MoveZone", new Vector2(0, 0), new Vector2(0.42f, 0.55f));
        lookZone = CreateZone(canvas.transform, "LookZone", new Vector2(0.42f, 0), new Vector2(1, 1));
        Image lookImage = lookZone.gameObject.AddComponent<Image>();
        lookImage.color = new Color(0, 0, 0, 0.001f);

        GameObject baseObj = CreatePanel(canvas.transform, "JoystickBase", new Vector2(0, 0), new Vector2(0, 0), new Vector2(190, 190), 0.16f);
        joystickBase = baseObj.GetComponent<RectTransform>();
        joystickBase.gameObject.SetActive(false);
        GameObject knobObj = CreatePanel(baseObj.transform, "JoystickKnob", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(82, 82), 0.30f);
        joystickKnob = knobObj.GetComponent<RectTransform>();

        CreateButton("Fire", "FIRE", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-150, 190), new Vector2(145, 145), 0.32f);
        CreateButton("Aim", "AIM", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-315, 205), new Vector2(105, 105), 0.26f);
        CreateButton("Reload", "R", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-335, 80), new Vector2(82, 82), 0.26f);
        CreateButton("Jump", "↑", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-80, 335), new Vector2(100, 100), 0.26f);
        CreateButton("Crouch", "C", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-80, 220), new Vector2(100, 90), 0.24f);
        CreateButton("Sprint", "RUN", new Vector2(0, 0), new Vector2(0, 0), new Vector2(255, 105), new Vector2(105, 75), 0.22f);
        CreateButton("Bomb", "USE", new Vector2(1, 1), new Vector2(1, 1), new Vector2(-145, -160), new Vector2(120, 80), 0.25f);

        CreateButton("Weapon0", "1", new Vector2(1, 1), new Vector2(1, 1), new Vector2(-420, -85), new Vector2(70, 65), 0.22f);
        CreateButton("Weapon1", "2", new Vector2(1, 1), new Vector2(1, 1), new Vector2(-335, -85), new Vector2(70, 65), 0.22f);
        CreateButton("Weapon2", "3", new Vector2(1, 1), new Vector2(1, 1), new Vector2(-250, -85), new Vector2(70, 65), 0.22f);

        CreateLabel(canvas.transform, "MobileHint", "LEFT: MOVE   RIGHT: LOOK", new Vector2(0, 1), new Vector2(35, -35), new Vector2(500, 45), 22);
    }

    private RectTransform CreateZone(Transform parent, string name, Vector2 anchorMin, Vector2 anchorMax)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        RectTransform rt = go.AddComponent<RectTransform>();
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
        return rt;
    }

    private GameObject CreatePanel(Transform parent, string name, Vector2 anchor, Vector2 pivot, Vector2 size, float alpha)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        Image image = go.AddComponent<Image>();
        image.color = new Color(1, 1, 1, alpha);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.pivot = pivot;
        rt.sizeDelta = size;
        return go;
    }

    private void CreateButton(string action, string label, Vector2 anchor, Vector2 pivot, Vector2 position, Vector2 size, float alpha)
    {
        GameObject go = CreatePanel(canvas.transform, action, anchor, pivot, size, alpha);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchoredPosition = position;
        buttons.Add(new ControlButton { rect = rt, action = action });
        CreateLabel(go.transform, "Label", label, new Vector2(0.5f, 0.5f), Vector2.zero, size, Mathf.RoundToInt(size.y * 0.25f));
    }

    private void CreateLabel(Transform parent, string name, string text, Vector2 anchor, Vector2 position, Vector2 size, int fontSize)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        Text uiText = go.AddComponent<Text>();
        uiText.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        uiText.text = text;
        uiText.fontSize = fontSize;
        uiText.alignment = TextAnchor.MiddleCenter;
        uiText.color = Color.white;
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = position;
        rt.sizeDelta = size;
    }
}
