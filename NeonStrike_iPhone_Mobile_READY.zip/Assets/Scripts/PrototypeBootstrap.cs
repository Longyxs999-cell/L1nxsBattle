
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PrototypeBootstrap : MonoBehaviour
{
    [Header("Prototype options")]
    public Team playerTeam = Team.Orange;
    public PrototypeMapBuilder mapBuilder;
    public TacticalGameManager gameManager;

    private PlayerController player;
    private HUDController hud;

    private void Awake()
    {
        Application.targetFrameRate = 120;

        if (mapBuilder == null)
        {
            GameObject map = new GameObject("Map");
            mapBuilder = map.AddComponent<PrototypeMapBuilder>();
        }

        mapBuilder.Build();

        if (gameManager == null)
        {
            GameObject gm = new GameObject("TacticalGameManager");
            gameManager = gm.AddComponent<TacticalGameManager>();
        }

        CreatePlayer();
        CreateBots();

        gameManager.siteA = mapBuilder.SiteA;
        gameManager.siteB = mapBuilder.SiteB;

        GameObject bombObject = new GameObject("BombController");
        BombController bomb = bombObject.AddComponent<BombController>();
        gameManager.bomb = bomb;

        CreateHUD();
        CreateMobileControls();
        CreateLighting();
    }

    private void CreatePlayer()
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        go.name = "Player";
        Transform playerSpawn = playerTeam == Team.Blue ? mapBuilder.BlueSpawn : mapBuilder.OrangeSpawn;
        go.transform.position = playerSpawn.position;
        go.transform.rotation = playerSpawn.rotation;

        Destroy(go.GetComponent<CapsuleCollider>());

        CharacterController cc = go.AddComponent<CharacterController>();
        cc.height = 1.8f;
        cc.radius = 0.32f;
        cc.center = new Vector3(0, 0.9f, 0);

        Health hp = go.AddComponent<Health>();
        hp.team = playerTeam;
        hp.isBot = false;

        GameObject camObject = new GameObject("PlayerCamera");
        camObject.transform.SetParent(go.transform);
        camObject.transform.localPosition = new Vector3(0, 1.65f, 0);
        Camera cam = camObject.AddComponent<Camera>();
        cam.tag = "MainCamera";
        cam.fieldOfView = 78f;

        GameObject weaponPivot = new GameObject("WeaponPivot");
        weaponPivot.transform.SetParent(camObject.transform);
        weaponPivot.transform.localPosition = Vector3.zero;

        PlayerController pc = go.AddComponent<PlayerController>();
        pc.playerCamera = cam;
        pc.weaponPivot = weaponPivot.transform;

        WeaponController wc = go.AddComponent<WeaponController>();
        wc.owner = hp;
        wc.playerCamera = cam;
        wc.weaponPivot = weaponPivot.transform;

        pc.weapon = wc;
        player = pc;

        SpawnPoint[] spawns = FindObjectsByType<SpawnPoint>(FindObjectsSortMode.None);
        foreach (SpawnPoint sp in spawns)
            if (sp.team == playerTeam) sp.target = hp;
    }

    private void CreateBots()
    {
        CreateBot("BlueBot_1", Team.Blue, mapBuilder.BlueSpawn.position + new Vector3(2, 0, 1));
        CreateBot("BlueBot_2", Team.Blue, mapBuilder.BlueSpawn.position + new Vector3(-2, 0, 2));
        CreateBot("BlueBot_3", Team.Blue, mapBuilder.BlueSpawn.position + new Vector3(3, 0, -2));
        CreateBot("BlueBot_4", Team.Blue, mapBuilder.BlueSpawn.position + new Vector3(-3, 0, -2));

        CreateBot("OrangeBot_1", Team.Orange, mapBuilder.OrangeSpawn.position + new Vector3(2, 0, 1));
        CreateBot("OrangeBot_2", Team.Orange, mapBuilder.OrangeSpawn.position + new Vector3(-2, 0, 2));
        CreateBot("OrangeBot_3", Team.Orange, mapBuilder.OrangeSpawn.position + new Vector3(3, 0, -2));
        CreateBot("OrangeBot_4", Team.Orange, mapBuilder.OrangeSpawn.position + new Vector3(-3, 0, -2));
    }

    private void CreateBot(string name, Team team, Vector3 position)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        go.name = name;
        go.transform.position = position;
        go.transform.localScale = new Vector3(0.9f, 1f, 0.9f);

        Health hp = go.AddComponent<Health>();
        hp.team = team;
        hp.isBot = true;

        BotController bot = go.AddComponent<BotController>();
        bot.Initialize(team, mapBuilder.Waypoints);

        // Separate head hitbox.
        GameObject head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        head.name = "Head";
        head.tag = "Head";
        head.transform.SetParent(go.transform);
        head.transform.localPosition = new Vector3(0, 0.72f, 0);
        head.transform.localScale = new Vector3(0.55f, 0.55f, 0.55f);
        Destroy(head.GetComponent<SphereCollider>());
        SphereCollider sc = head.AddComponent<SphereCollider>();
        sc.isTrigger = false;

        Renderer r = go.GetComponent<Renderer>();
        r.material = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        r.material.color = team == Team.Blue
            ? new Color(0.1f, 0.35f, 0.9f)
            : new Color(0.95f, 0.35f, 0.08f);
    }

    private void CreateHUD()
    {
        GameObject canvasObject = new GameObject("HUD");
        Canvas canvas = canvasObject.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObject.AddComponent<CanvasScaler>().uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        canvasObject.GetComponent<CanvasScaler>().referenceResolution = new Vector2(1920, 1080);
        canvasObject.AddComponent<GraphicRaycaster>();

        hud = canvasObject.AddComponent<HUDController>();
        hud.scoreText = CreateText(canvasObject.transform, "Score", new Vector2(0.5f, 1), new Vector2(0, -45), 30);
        hud.timerText = CreateText(canvasObject.transform, "Timer", new Vector2(0.5f, 1), new Vector2(0, -90), 26);
        hud.statusText = CreateText(canvasObject.transform, "Status", new Vector2(0.5f, 1), new Vector2(0, -135), 22);
        hud.weaponText = CreateText(canvasObject.transform, "Weapon", new Vector2(1, 1), new Vector2(-180, -55), 24);
        hud.ammoText = CreateText(canvasObject.transform, "Ammo", new Vector2(1, 1), new Vector2(-170, -90), 30);
        hud.healthText = CreateText(canvasObject.transform, "Health", new Vector2(0, 0), new Vector2(140, 70), 30);

        hud.Bind(player);

        GameObject cross = new GameObject("Crosshair");
        cross.transform.SetParent(canvasObject.transform, false);
        Text crossText = cross.AddComponent<Text>();
        crossText.text = "+";
        crossText.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        crossText.fontSize = 36;
        crossText.alignment = TextAnchor.MiddleCenter;
        RectTransform cr = cross.GetComponent<RectTransform>();
        cr.anchorMin = new Vector2(0.5f, 0.5f);
        cr.anchorMax = new Vector2(0.5f, 0.5f);
        cr.anchoredPosition = Vector2.zero;
        cr.sizeDelta = new Vector2(60, 60);
    }

    private Text CreateText(Transform parent, string name, Vector2 anchor, Vector2 offset, int size)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);

        Text t = go.AddComponent<Text>();
        t.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        t.fontSize = size;
        t.color = Color.white;
        t.alignment = TextAnchor.MiddleCenter;

        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.anchoredPosition = offset;
        rt.sizeDelta = new Vector2(420, 55);

        return t;
    }


    private void CreateMobileControls()
    {
        GameObject mobile = new GameObject("MobileInputController");
        MobileInputController input = mobile.AddComponent<MobileInputController>();
        input.forceMobileControls = false;
    }
    private void CreateLighting()
    {
        GameObject lightObject = new GameObject("Sun");
        Light light = lightObject.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.1f;
        light.transform.rotation = Quaternion.Euler(50, -35, 0);

        RenderSettings.ambientLight = new Color(0.16f, 0.18f, 0.22f);
    }
}
