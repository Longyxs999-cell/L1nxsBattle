
using UnityEngine;

public class BombSite : MonoBehaviour
{
    public string siteId = "A";
    public float radius = 3.5f;

    private void OnDrawGizmos()
    {
        Gizmos.color = siteId == "A" ? Color.cyan : Color.yellow;
        Gizmos.DrawWireSphere(transform.position, radius);
    }
}
