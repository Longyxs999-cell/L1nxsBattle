
using System.Collections.Generic;
using UnityEngine;

public class PrototypeMapBuilder : MonoBehaviour
{
    public Material wallMaterial;
    public Material floorMaterial;
    public Material accentMaterial;
    public Material crateMaterial;

    public float mapWidth = 60f;
    public float mapLength = 42f;
    public float wallHeight = 4f;

    public Transform BlueSpawn { get; private set; }
    public Transform OrangeSpawn { get; private set; }
    public BombSite SiteA { get; private set; }
    public BombSite SiteB { get; private set; }
    public List<Transform> Waypoints { get; } = new List<Transform>();

    public void Build()
    {
        ClearOldMap();
        EnsureMaterials();

        CreateBox("Ground", new Vector3(0, -0.5f, 0), new Vector3(mapWidth, 1, mapLength), floorMaterial);

        // Outer walls.
        CreateBox("Wall_North", new Vector3(0, wallHeight / 2f, mapLength / 2f), new Vector3(mapWidth, wallHeight, 1), wallMaterial);
        CreateBox("Wall_South", new Vector3(0, wallHeight / 2f, -mapLength / 2f), new Vector3(mapWidth, wallHeight, 1), wallMaterial);
        CreateBox("Wall_East", new Vector3(mapWidth / 2f, wallHeight / 2f, 0), new Vector3(1, wallHeight, mapLength), wallMaterial);
        CreateBox("Wall_West", new Vector3(-mapWidth / 2f, wallHeight / 2f, 0), new Vector3(1, wallHeight, mapLength), wallMaterial);

        // Industrial central building creates three main lanes.
        CreateBox("CentralWarehouse_N", new Vector3(0, wallHeight / 2f, 10), new Vector3(22, wallHeight, 1), wallMaterial);
        CreateBox("CentralWarehouse_S", new Vector3(0, wallHeight / 2f, -10), new Vector3(22, wallHeight, 1), wallMaterial);
        CreateBox("CentralWarehouse_W", new Vector3(-11, wallHeight / 2f, 0), new Vector3(1, wallHeight, 20), wallMaterial);
        CreateBox("CentralWarehouse_E", new Vector3(11, wallHeight / 2f, 0), new Vector3(1, wallHeight, 20), wallMaterial);

        // Door gaps represented by leaving openings in the four sides.
        CreateBox("WarehouseRoof", new Vector3(0, wallHeight + 0.15f, 0), new Vector3(22, 0.3f, 20), wallMaterial);

        // A site: north-west courtyard.
        CreateSite("BombSite_A", "A", new Vector3(-19, 0.02f, 13));
        // B site: south-east yard.
        CreateSite("BombSite_B", "B", new Vector3(19, 0.02f, -13));

        // Cover and industrial props.
        Crate("Cover_A1", new Vector3(-15, 1, 8), new Vector3(3, 2, 3));
        Crate("Cover_A2", new Vector3(-7, 1, 15), new Vector3(4, 2, 2));
        Crate("Cover_Mid1", new Vector3(0, 1, 0), new Vector3(3, 2, 3));
        Crate("Cover_Mid2", new Vector3(6, 1, 4), new Vector3(2, 2, 4));
        Crate("Cover_B1", new Vector3(15, 1, -8), new Vector3(3, 2, 3));
        Crate("Cover_B2", new Vector3(7, 1, -15), new Vector3(4, 2, 2));

        // Long lanes broken with cover so no single position sees the whole map.
        Crate("LaneBlock_W1", new Vector3(-23, 1, 0), new Vector3(3, 2, 4));
        Crate("LaneBlock_E1", new Vector3(23, 1, 0), new Vector3(3, 2, 4));

        CreateSpawn("BlueSpawn", Team.Blue, new Vector3(-24, 0, -17), Quaternion.Euler(0, 35, 0));
        CreateSpawn("OrangeSpawn", Team.Orange, new Vector3(24, 0, 17), Quaternion.Euler(0, -145, 0));

        // Waypoints for bots.
        AddWaypoint("WP_A", new Vector3(-18, 0, 8));
        AddWaypoint("WP_A_Mid", new Vector3(-9, 0, 7));
        AddWaypoint("WP_Mid1", new Vector3(-6, 0, 0));
        AddWaypoint("WP_Mid2", new Vector3(6, 0, 0));
        AddWaypoint("WP_B_Mid", new Vector3(9, 0, -7));
        AddWaypoint("WP_B", new Vector3(18, 0, -8));
        AddWaypoint("WP_North", new Vector3(0, 0, 18));
        AddWaypoint("WP_South", new Vector3(0, 0, -18));
    }

    private void EnsureMaterials()
    {
        if (wallMaterial == null) wallMaterial = MakeMaterial(new Color(0.24f, 0.27f, 0.3f));
        if (floorMaterial == null) floorMaterial = MakeMaterial(new Color(0.12f, 0.14f, 0.16f));
        if (accentMaterial == null) accentMaterial = MakeMaterial(new Color(0.05f, 0.7f, 1f));
        if (crateMaterial == null) crateMaterial = MakeMaterial(new Color(0.35f, 0.22f, 0.1f));
    }

    private Material MakeMaterial(Color color)
    {
        Material m = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        m.color = color;
        return m;
    }

    private void ClearOldMap()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
            DestroyImmediate(transform.GetChild(i).gameObject);

        Waypoints.Clear();
    }

    private GameObject CreateBox(string name, Vector3 position, Vector3 size, Material material)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name;
        go.transform.SetParent(transform);
        go.transform.position = position;
        go.transform.localScale = size;
        go.GetComponent<Renderer>().material = material;
        return go;
    }

    private void Crate(string name, Vector3 position, Vector3 size)
    {
        CreateBox(name, position, size, crateMaterial);
    }

    private void CreateSite(string name, string id, Vector3 position)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        go.name = name;
        go.transform.SetParent(transform);
        go.transform.position = position;
        go.transform.localScale = new Vector3(3.5f, 0.08f, 3.5f);
        go.GetComponent<Renderer>().material = accentMaterial;

        BombSite site = go.AddComponent<BombSite>();
        site.siteId = id;
        site.radius = 3.5f;

        if (id == "A") SiteA = site;
        else SiteB = site;
    }

    private void CreateSpawn(string name, Team team, Vector3 position, Quaternion rotation)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(transform);
        go.transform.SetPositionAndRotation(position, rotation);

        SpawnPoint sp = go.AddComponent<SpawnPoint>();
        sp.team = team;

        if (team == Team.Blue) BlueSpawn = go.transform;
        else OrangeSpawn = go.transform;
    }

    private void AddWaypoint(string name, Vector3 position)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(transform);
        go.transform.position = position;
        Waypoints.Add(go.transform);
    }
}
