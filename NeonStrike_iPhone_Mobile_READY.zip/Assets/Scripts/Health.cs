
using UnityEngine;

public class Health : MonoBehaviour
{
    public Team team;
    public int maxHealth = 100;
    public bool isBot;

    public int CurrentHealth { get; private set; }
    public bool IsAlive => CurrentHealth > 0;

    private void Awake()
    {
        CurrentHealth = maxHealth;
    }

    public void ResetHealth()
    {
        CurrentHealth = maxHealth;
        gameObject.SetActive(true);
    }

    public void TakeDamage(int amount, GameObject attacker, bool headshot)
    {
        if (!IsAlive) return;

        CurrentHealth -= Mathf.Max(1, amount);
        if (CurrentHealth <= 0)
        {
            CurrentHealth = 0;
            TacticalGameManager.Instance?.RegisterKill(attacker, gameObject, headshot);
            gameObject.SetActive(false);
        }
    }
}
