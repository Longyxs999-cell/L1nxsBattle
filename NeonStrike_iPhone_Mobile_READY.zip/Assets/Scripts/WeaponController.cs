
using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

public class WeaponController : MonoBehaviour
{
    public Camera playerCamera;
    public Health owner;
    public Transform weaponPivot;
    public GameObject hitEffectPrefab;

    public WeaponConfig[] loadout =
    {
        WeaponConfig.Pistol(),
        WeaponConfig.Rifle(),
        WeaponConfig.Sniper()
    };

    private int currentIndex = 1;
    private int ammoInMagazine;
    private int reserveAmmo;
    private float nextShotTime;
    private bool reloading;
    private Coroutine reloadRoutine;

    public WeaponConfig Current => loadout[currentIndex];
    public int AmmoInMagazine => ammoInMagazine;
    public int ReserveAmmo => reserveAmmo;
    public bool IsReloading => reloading;
    public bool IsAiming { get; private set; }
    public float normalFov = 78f;
    public float aimFov = 55f;

    private void Start()
    {
        Equip(currentIndex);
    }

    private void Update()
    {
        if (owner == null || !owner.IsAlive) return;

        MobileInputController mobile = MobileInputController.Instance;
        bool useMobile = mobile != null && mobile.IsMobile;

        if (useMobile)
        {
            if (mobile.WeaponPressed >= 0) Equip(mobile.WeaponPressed);
            if (mobile.ReloadPressed) StartReload();
            SetAiming(mobile.AimHeld);
            if (mobile.FireHeld) TryFire();
        }
        else
        {
            if (Keyboard.current != null)
            {
                if (Keyboard.current.digit1Key.wasPressedThisFrame) Equip(0);
                if (Keyboard.current.digit2Key.wasPressedThisFrame) Equip(1);
                if (Keyboard.current.digit3Key.wasPressedThisFrame) Equip(2);
                if (Keyboard.current.rKey.wasPressedThisFrame) StartReload();
            }
            SetAiming(Mouse.current != null && Mouse.current.rightButton.isPressed);
            if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame) TryFire();
            if (Current.automatic && Mouse.current != null && Mouse.current.leftButton.isPressed) TryFire();
        }
    }

    public void SetAiming(bool aiming)
    {
        IsAiming = aiming && !reloading;
        if (playerCamera != null)
            playerCamera.fieldOfView = Mathf.Lerp(playerCamera.fieldOfView, IsAiming ? aimFov : normalFov, 18f * Time.deltaTime);
    }

    public void Equip(int index)
    {
        if (index < 0 || index >= loadout.Length) return;
        currentIndex = index;
        ammoInMagazine = loadout[index].magazineSize;
        reserveAmmo = loadout[index].reserveAmmo;
        reloading = false;
        if (reloadRoutine != null) StopCoroutine(reloadRoutine);
        ApplyWeaponVisual();
    }

    public void StartReload()
    {
        if (reloading || ammoInMagazine >= Current.magazineSize || reserveAmmo <= 0) return;
        reloadRoutine = StartCoroutine(ReloadRoutine());
    }

    private IEnumerator ReloadRoutine()
    {
        reloading = true;
        yield return new WaitForSeconds(Current.reloadTime);
        int needed = Current.magazineSize - ammoInMagazine;
        int taken = Mathf.Min(needed, reserveAmmo);
        ammoInMagazine += taken;
        reserveAmmo -= taken;
        reloading = false;
    }

    public void TryFire()
    {
        if (reloading || Time.time < nextShotTime || ammoInMagazine <= 0) return;

        nextShotTime = Time.time + 1f / Current.fireRate;
        ammoInMagazine--;

        Vector3 origin = playerCamera.transform.position;
        Vector3 direction = playerCamera.transform.forward;

        float spread = Current.kind == WeaponKind.Sniper ? 0.002f : 0.012f;
        direction = Quaternion.Euler(
            Random.Range(-spread, spread) * 100f,
            Random.Range(-spread, spread) * 100f,
            0f) * direction;

        if (Physics.Raycast(origin, direction, out RaycastHit hit, Current.range))
        {
            Health target = hit.collider.GetComponentInParent<Health>();
            if (target != null && target != owner && target.team != owner.team)
            {
                bool headshot = hit.collider.CompareTag("Head");
                int damage = headshot ? Mathf.RoundToInt(Current.damage * 2.0f) : Current.damage;
                target.TakeDamage(damage, owner.gameObject, headshot);
            }

            if (hitEffectPrefab != null)
            {
                GameObject fx = Instantiate(hitEffectPrefab, hit.point, Quaternion.LookRotation(hit.normal));
                Destroy(fx, 1f);
            }
        }

        PlayerController local = owner.GetComponent<PlayerController>();
        if (local != null) local.ApplyRecoil(Current.recoil);
    }

    private void ApplyWeaponVisual()
    {
        if (weaponPivot == null) return;

        for (int i = weaponPivot.childCount - 1; i >= 0; i--)
            Destroy(weaponPivot.GetChild(i).gameObject);

        GameObject body = GameObject.CreatePrimitive(PrimitiveType.Cube);
        body.name = Current.displayName + "_ViewModel";
        body.transform.SetParent(weaponPivot, false);

        Vector3 scale = Current.kind == WeaponKind.Pistol
            ? new Vector3(0.12f, 0.12f, 0.38f)
            : Current.kind == WeaponKind.Rifle
                ? new Vector3(0.16f, 0.16f, 0.72f)
                : new Vector3(0.13f, 0.13f, 0.9f);

        body.transform.localScale = scale;
        body.transform.localPosition = new Vector3(0.18f, -0.12f, 0.48f);
        body.transform.localRotation = Quaternion.Euler(0f, 0f, -5f);

        Renderer r = body.GetComponent<Renderer>();
        r.material = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        r.material.color = Current.kind == WeaponKind.Sniper
            ? new Color(0.15f, 0.2f, 0.25f)
            : new Color(0.08f, 0.1f, 0.12f);
    }
}
