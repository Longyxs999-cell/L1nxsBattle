# Neon Strike — iPhone preparation

This project is prepared for landscape touch controls on iPhone/iPad.

## Mobile controls
- Left thumb: virtual joystick / movement
- Right thumb: swipe / camera look
- FIRE: shooting
- AIM: hold to aim
- R: reload
- 1/2/3: switch weapons
- ↑: jump
- C: crouch
- RUN: sprint
- USE: hold near a bomb site to plant/defuse when the round rules allow it

The UI is created automatically by `MobileInputController.cs`, so there is no manual Canvas wiring.

## iOS build
A real `.ipa` still requires Unity Editor with iOS Build Support and an Apple/Xcode build environment. The source project itself can be opened and prepared on a computer; an iPhone cannot run Unity Editor locally.

## Android build
Android Build Support can be added in Unity Hub if an APK is also desired.
